import enum

class Activation(enum.Enum):
    linear = 1
    RELU = 2
    sigmoid = 3
    softmax = 4

