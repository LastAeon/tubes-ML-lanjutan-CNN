# tubes ML lanjutan - CNN
 
